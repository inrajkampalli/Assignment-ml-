#!/usr/bin/env python3
"""
MetaStacker MLOps Batch Processing Job
Reproducible, observable, and dockerized batch signal processor.
"""

import argparse
import json
import logging
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import yaml


# ---------------------------------------------------------------------------
# Config dataclass
# ---------------------------------------------------------------------------

@dataclass
class Config:
    seed: int
    window: int
    version: str

    def __post_init__(self):
        if not isinstance(self.seed, int) or self.seed < 0:
            raise ValueError(f"Config 'seed' must be a non-negative integer, got: {self.seed!r}")
        if not isinstance(self.window, int) or self.window < 1:
            raise ValueError(f"Config 'window' must be a positive integer, got: {self.window!r}")
        if not isinstance(self.version, str) or not self.version.strip():
            raise ValueError(f"Config 'version' must be a non-empty string, got: {self.version!r}")


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def setup_logging(log_file: Optional[str]) -> logging.Logger:
    logger = logging.getLogger("metastacker")
    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s — %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    # Always log to stdout
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    # Optionally log to file
    if log_file:
        fh = logging.FileHandler(log_file)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------

def load_config(config_path: str) -> Config:
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    with path.open("r") as f:
        raw = yaml.safe_load(f)
    if not isinstance(raw, dict):
        raise ValueError("Config YAML must be a mapping at the top level.")
    required_keys = {"seed", "window", "version"}
    missing = required_keys - raw.keys()
    if missing:
        raise ValueError(f"Config is missing required keys: {missing}")
    return Config(
        seed=raw["seed"],
        window=raw["window"],
        version=str(raw["version"]),
    )


# ---------------------------------------------------------------------------
# Data loader & validator
# ---------------------------------------------------------------------------

def load_and_validate_data(input_path: str, logger: logging.Logger) -> pd.DataFrame:
    path = Path(input_path)
    if not path.exists():
        raise FileNotFoundError(f"Input data file not found: {input_path}")

    df = pd.read_csv(path)
    logger.info(f"Loaded data from '{input_path}': {len(df)} rows, {len(df.columns)} columns.")

    if df.empty:
        raise ValueError("Input data is empty (0 rows).")

    if "close" not in df.columns:
        raise ValueError(
            f"Required column 'close' not found. Available columns: {list(df.columns)}"
        )

    # Production-grade type check: ensure 'close' is numeric
    if not pd.api.types.is_numeric_dtype(df["close"]):
        # Attempt coercion and report non-numeric rows
        coerced = pd.to_numeric(df["close"], errors="coerce")
        bad_rows = coerced.isna().sum()
        raise TypeError(
            f"Column 'close' must contain numeric values, but found {bad_rows} "
            f"non-numeric / NaN entries. Please clean your data before processing."
        )

    null_count = df["close"].isna().sum()
    if null_count > 0:
        raise ValueError(
            f"Column 'close' contains {null_count} NaN value(s). "
            "Please resolve missing values before processing."
        )

    logger.info(f"Data validation passed. 'close' column is numeric with {len(df)} valid rows.")
    return df


# ---------------------------------------------------------------------------
# Signal computation
# ---------------------------------------------------------------------------

def compute_signals(df: pd.DataFrame, window: int, logger: logging.Logger) -> pd.DataFrame:
    df = df.copy()
    df["rolling_mean"] = df["close"].rolling(window=window, min_periods=window).mean()

    # Signal is only computed where rolling_mean is available (i.e., not NaN)
    df["signal"] = np.where(
        df["rolling_mean"].isna(),
        np.nan,
        np.where(df["close"] > df["rolling_mean"], 1, 0),
    )

    valid_signals = df["signal"].notna().sum()
    skipped_rows = df["signal"].isna().sum()
    logger.info(
        f"Signals computed: {int(valid_signals)} rows with signal, "
        f"{int(skipped_rows)} initial rows skipped (window warm-up)."
    )
    return df


# ---------------------------------------------------------------------------
# Metrics builder
# ---------------------------------------------------------------------------

def build_metrics(
    version: str,
    rows_processed: int,
    signal_rate: float,
    latency_ms: float,
    seed: int,
    status: str,
) -> dict:
    return {
        "version": version,
        "rows_processed": rows_processed,
        "metric": "signal_rate",
        "value": round(signal_rate, 6),
        "latency_ms": round(latency_ms, 3),
        "seed": seed,
        "status": status,
    }


def save_metrics(metrics: dict, output_dir: Path, logger: logging.Logger) -> None:
    metrics_path = output_dir / "metrics.json"
    with metrics_path.open("w") as f:
        json.dump(metrics, f, indent=2)
    logger.info(f"Metrics saved to '{metrics_path}'.")
    # Always print final JSON to stdout (required by Docker spec)
    print(json.dumps(metrics, indent=2))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="MetaStacker: Reproducible MLOps batch signal processor."
    )
    parser.add_argument("--input", required=True, help="Path to input CSV file.")
    parser.add_argument("--config", required=True, help="Path to YAML config file.")
    parser.add_argument("--output", required=True, help="Path to output directory.")
    parser.add_argument("--log-file", default=None, help="Optional path to log file.")
    return parser.parse_args()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    args = parse_args()
    logger = setup_logging(args.log_file)
    start_time = time.monotonic()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 60)
    logger.info("MetaStacker batch job starting.")
    logger.info(f"  input   : {args.input}")
    logger.info(f"  config  : {args.config}")
    logger.info(f"  output  : {args.output}")
    logger.info("=" * 60)

    # Placeholders for metrics on early failures
    version = "unknown"
    seed = -1
    rows_processed = 0

    try:
        # --- Config ---
        logger.info("Loading and validating config...")
        cfg = load_config(args.config)
        version = cfg.version
        seed = cfg.seed
        logger.info(
            f"Config validated: seed={cfg.seed}, window={cfg.window}, version={cfg.version}"
        )

        # --- Seed ---
        np.random.seed(cfg.seed)
        logger.info(f"Global numpy random seed set to {cfg.seed}.")

        # --- Data ---
        logger.info("Loading and validating input data...")
        df = load_and_validate_data(args.input, logger)
        rows_processed = len(df)

        # --- Signals ---
        logger.info(f"Computing rolling signals with window={cfg.window}...")
        df = compute_signals(df, cfg.window, logger)

        # --- Signal rate (over valid rows only) ---
        valid_mask = df["signal"].notna()
        valid_count = valid_mask.sum()
        signal_rate = float(df.loc[valid_mask, "signal"].mean()) if valid_count > 0 else 0.0

        # --- Save output CSV ---
        output_csv = output_dir / "output.csv"
        df.to_csv(output_csv, index=False)
        logger.info(f"Output CSV written to '{output_csv}'.")

        latency_ms = (time.monotonic() - start_time) * 1000
        metrics = build_metrics(version, rows_processed, signal_rate, latency_ms, seed, "success")
        save_metrics(metrics, output_dir, logger)
        logger.info("MetaStacker batch job completed successfully.")
        return 0

    except (FileNotFoundError, ValueError, TypeError) as exc:
        logger.error(f"Job failed: {exc}")
        latency_ms = (time.monotonic() - start_time) * 1000
        metrics = build_metrics(version, rows_processed, 0.0, latency_ms, seed, f"error: {exc}")
        save_metrics(metrics, output_dir, logger)
        return 1

    except Exception as exc:
        logger.exception(f"Unexpected error: {exc}")
        latency_ms = (time.monotonic() - start_time) * 1000
        metrics = build_metrics(version, rows_processed, 0.0, latency_ms, seed, f"error: {exc}")
        save_metrics(metrics, output_dir, logger)
        return 2


if __name__ == "__main__":
    sys.exit(main())
