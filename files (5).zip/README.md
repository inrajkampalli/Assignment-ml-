# MetaStacker — MLOps Batch Signal Processor

A reproducible, observable, and Dockerized batch job that computes rolling-mean signals over OHLCV price data.

---

## Project Structure

```
metastacker/
├── run.py            # Main processing script
├── requirements.txt  # Python dependencies
├── Dockerfile        # Container definition
├── config.yaml       # Job configuration
├── data.csv          # Sample input data
└── README.md         # This file
```

---

## Configuration (`config.yaml`)

| Field     | Type   | Description                          |
|-----------|--------|--------------------------------------|
| `seed`    | int    | Global numpy random seed (≥ 0)       |
| `window`  | int    | Rolling mean window size (≥ 1)       |
| `version` | string | Job version label for metrics output |

---

## Running Locally

### Prerequisites

```bash
pip install -r requirements.txt
```

### Basic run

```bash
python run.py \
  --input data.csv \
  --config config.yaml \
  --output ./output
```

### With log file

```bash
python run.py \
  --input data.csv \
  --config config.yaml \
  --output ./output \
  --log-file ./output/job.log
```

---

## Docker

### Build the image

```bash
docker build -t metastacker:latest .
```

### Run with bundled defaults (data.csv + config.yaml baked in)

```bash
docker run --rm metastacker:latest
```

### Run with custom files mounted at runtime

```bash
docker run --rm \
  -v "$(pwd)/my_data.csv:/app/data.csv" \
  -v "$(pwd)/my_config.yaml:/app/config.yaml" \
  -v "$(pwd)/output:/app/output" \
  metastacker:latest \
  --input /app/data.csv \
  --config /app/config.yaml \
  --output /app/output
```

### Capture only the JSON metrics from stdout

```bash
docker run --rm metastacker:latest 2>/dev/null
```

---

## Outputs

| File              | Description                                      |
|-------------------|--------------------------------------------------|
| `output/output.csv`   | Input data enriched with `rolling_mean` and `signal` columns |
| `output/metrics.json` | Job metrics (always written, success or failure) |

### `metrics.json` schema

```json
{
  "version": "1.0.0",
  "rows_processed": 10,
  "metric": "signal_rate",
  "value": 0.8,
  "latency_ms": 42.3,
  "seed": 42,
  "status": "success"
}
```

---

## Signal Logic

| Condition                       | Signal |
|---------------------------------|--------|
| `close > rolling_mean`          | `1`    |
| `close ≤ rolling_mean`          | `0`    |
| Insufficient rows (warm-up)     | `NaN`  |

The first `window - 1` rows are skipped during the rolling warm-up phase and will have `NaN` in the `signal` column.

---

## Validation Checks

- Config fields are type-checked via a `@dataclass` with `__post_init__` guards.
- Input CSV must be non-empty and contain a `close` column.
- The `close` column must be **numeric** — non-numeric values raise a `TypeError` with a descriptive message.
- NaN values in `close` are rejected before processing.

---

## Exit Codes

| Code | Meaning                                   |
|------|-------------------------------------------|
| `0`  | Success                                   |
| `1`  | Known error (bad config, bad data, etc.)  |
| `2`  | Unexpected / unhandled exception          |

---

## GitHub Push

```bash
git init
git add .
git commit -m "feat: initial MetaStacker MLOps batch job"
git remote add origin https://github.com/<your-username>/metastacker.git
git push -u origin main
```
